# SportOps — University Athletics Management System
**CSC 3326 – Database Systems**  
Team: Badreddine Guellass · Ikram El Brouzi · Nada El Yassenasni · Nora Barakat · Wiam Alaoui Hachimi

---

## Tech Stack
| Layer     | Technology          |
|-----------|---------------------|
| Database  | PostgreSQL          |
| Backend   | Node.js + Express   |
| Auth      | JWT + bcrypt        |
| Frontend  | Vanilla HTML/CSS/JS |
| Charts    | Chart.js            |

---

## Setup Instructions

### 1. Database Setup
```sql
-- In psql:
\i sql/schema.sql
\i sql/data.sql
```

### 2. Backend Setup
```bash
cd backend
npm install
```

Edit `db.js` to match your PostgreSQL credentials:
```js
const pool = new Pool({
  user:     "postgres",
  host:     "localhost",
  database: "SportsOpsDB",
  password: "YOUR_PASSWORD",   // ← change this
  port:     5432,
});
```

### 3. Seed Demo Accounts
```bash
cd backend
node seed.js
```

This creates hashed passwords in the `Users` table.

### 4. Start the Server
```bash
npm start
# or for development with auto-reload:
npm run dev
```

Server runs on **http://localhost:3000**

### 5. Open the App
Navigate to: **http://localhost:3000/login.html**

---

## Demo Credentials

| Role    | Email                    | Password     |
|---------|--------------------------|--------------|
| Admin   | admin@sportops.ma        | admin123     |
| Athlete | b.guellass@aui.ma        | student123   |
| Coach   | n.karim@aui.ma           | coach123     |

All athlete accounts use password `student123`  
All coach accounts use password `coach123`

---

## Features by Role

### 🔐 Admin
- Full dashboard with system-wide stats
- View all teams, rosters, games, practices
- Approve or reject facility bookings
- Add facilities
- View all athletes

### 🏋 Coach
- Dashboard with team stats
- View their teams and rosters
- Schedule practices and tryouts
- Request facility bookings
- View participants per tryout
- Record game results
- View all athletes

### 🎓 Athlete
- Personal dashboard (teams joined, tryouts)
- Browse and register for upcoming tryouts
- View game results and schedules
- Check facility availability
- Personal profile with membership history

---

## API Endpoints

### Auth
| Method | Path         | Description              |
|--------|-------------|--------------------------|
| POST   | /auth/login | Login, returns JWT token |
| GET    | /auth/me    | Get current user profile |

### Dashboard
| GET | /dashboard/stats        | Role-aware summary stats  |
| GET | /dashboard/team-size    | Team sizes for bar chart  |
| GET | /dashboard/upcoming     | Upcoming events (14 days) |
| GET | /dashboard/game-results | Recent game results       |

### Teams
| GET  | /teams              | All teams with coach & member count |
| GET  | /teams/:id/members  | Team roster                         |
| POST | /teams              | Create team (admin)                 |

### Tryouts
| GET   | /tryouts                    | All tryouts                |
| GET   | /tryouts/upcoming           | Upcoming tryouts           |
| GET   | /tryouts/:id/participants   | Participants (coach/admin) |
| POST  | /tryouts                    | Schedule tryout            |
| POST  | /tryouts/register           | Register athlete           |

### Facilities
| GET  | /facilities              | All facilities with usage stats |
| GET  | /facilities/availability | Check availability for date     |
| GET  | /facilities/:id/hours    | Opening hours                   |
| POST | /facilities              | Add facility (admin)            |

### Bookings
| GET   | /bookings            | All bookings          |
| POST  | /bookings            | Request booking       |
| PATCH | /bookings/:id/approve| Approve (admin)       |
| PATCH | /bookings/:id/reject | Reject (admin)        |

### Games & Practices
| GET/POST | /games     | All games / Record game     |
| GET/POST | /practices | All practices / Schedule    |

### Students
| GET | /students          | All athletes (admin/coach) |
| GET | /students/:id/history | Membership & tryout history |

---

## Project Structure
```
sportops/
├── sql/
│   ├── schema.sql       ← DB creation + all tables
│   └── data.sql         ← Sample data
├── backend/
│   ├── server.js        ← Express app entry point
│   ├── db.js            ← PostgreSQL connection pool
│   ├── seed.js          ← Create demo user accounts
│   ├── middleware/
│   │   ├── auth.js      ← JWT verification
│   │   └── role.js      ← Role-based access control
│   ├── routes/
│   │   ├── auth.js      ← Login + /me
│   │   ├── dashboard.js ← Stats, charts, upcoming
│   │   ├── teams.js     ← Team management
│   │   ├── tryouts.js   ← Tryout scheduling + registration
│   │   ├── facilities.js← Facility info + availability
│   │   ├── bookings.js  ← Booking requests + approval
│   │   ├── games.js     ← Game results
│   │   ├── practices.js ← Practice sessions
│   │   └── students.js  ← Athlete management
│   └── package.json
└── frontend/
    ├── login.html       ← Login page
    └── dashboard.html   ← Full SPA dashboard
```
