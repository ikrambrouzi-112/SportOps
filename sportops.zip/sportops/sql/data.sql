-- ================================================
-- SportOps – Sample Data Population
-- ================================================
\c SportsOpsDB;

-- CLEAN DATABASE
TRUNCATE TABLE Membership CASCADE;
TRUNCATE TABLE Scores CASCADE;
TRUNCATE TABLE Registers CASCADE;
TRUNCATE TABLE Game CASCADE;
TRUNCATE TABLE FacilityBooking CASCADE;
TRUNCATE TABLE PracticeSession CASCADE;
TRUNCATE TABLE Tryout CASCADE;
TRUNCATE TABLE Team CASCADE;
TRUNCATE TABLE Club CASCADE;
TRUNCATE TABLE Coach CASCADE;
TRUNCATE TABLE Student CASCADE;

-- ================================================
-- STUDENTS
-- ================================================
INSERT INTO Student VALUES
(148454,'Badreddine','Guellass','b.guellass@aui.ma',NULL,'CSC'),
(148455,'Sara','El Idrissi','s.elidrissi@aui.ma',612345678,'BA'),
(148456,'Youssef','Amrani','y.amrani@aui.ma',623456789,'GE'),
(148457,'Lina','Bennani','l.bennani@aui.ma',634567890,'AI'),
(148458,'Hamza','Alaoui','h.alaoui@aui.ma',645678901,'EMS'),
(148459,'Maya','Tazi','m.tazi@aui.ma',656789012,'CSC'),
(148460,'Omar','Zahir','o.zahir@aui.ma',667890123,'AI'),
(148461,'Imane','Raji','i.raji@aui.ma',678901234,'BA'),
(148462,'Anas','Benjelloun','a.benjelloun@aui.ma',689012345,'GE'),
(148463,'Salma','Khattabi','s.khattabi@aui.ma',690123456,'EMS'),
(148464,'Reda','Nouri','r.nouri@aui.ma',601234567,'CSC'),
(148465,'Khadija','El Fassi','k.elfassi@aui.ma',612340987,'AI'),
(148466,'Yassine','Hariri','y.hariri@aui.ma',623450876,'BA'),
(148467,'Hiba','Mansouri','h.mansouri@aui.ma',634560765,'GE'),
(148468,'Ali','Chraibi','a.chraibi@aui.ma',645670654,'EMS'),
(148469,'Mehdi','Ait Lahcen','m.aitlahcen@aui.ma',612345001,'CSC'),
(148470,'Zineb','Bouzidi','z.bouzidi@aui.ma',612345002,'BA'),
(148471,'Ayoub','El Hamdi','a.elhamdi@aui.ma',612345003,'GE'),
(148472,'Nour','Chafiq','n.chafiq@aui.ma',612345004,'EMS'),
(148473,'Taha','El Khatib','t.elkhatib@aui.ma',612345005,'AI'),
(148474,'Asmaa','Berrada','a.berrada@aui.ma',612345006,'CSC'),
(148475,'Sami','Bennani','s.bennani@aui.ma',612345007,'BA'),
(148476,'Ilyas','Fadili','i.fadili@aui.ma',612345008,'GE'),
(148477,'Meryem','Skalli','m.skalli@aui.ma',612345009,'EMS'),
(148478,'Walid','Chakir','w.chakir@aui.ma',612345010,'AI'),
(148479,'Yasmine','Laaroussi','y.laaroussi@aui.ma',612345011,'CSC'),
(148480,'Rachid','El Idrissi','r.elidrissi@aui.ma',612345012,'BA'),
(148481,'Hassan','Alaoui','h.alaoui2@aui.ma',612345013,'GE'),
(148482,'Fatima','Zahra','f.zahra@aui.ma',612345014,'EMS'),
(148483,'Khalid','Meziane','k.meziane@aui.ma',612345015,'AI'),
(148484,'Ikram','El Boussi','i.elboussi@aui.ma',612345016,'CSC'),
(148485,'Nadia','Barkani','n.barkani@aui.ma',612345017,'BA'),
(148486,'Amine','Sefrioui','a.sefrioui@aui.ma',612345018,'GE'),
(148487,'Sanaa','Moutawakil','s.moutawakil@aui.ma',612345019,'EMS'),
(148488,'Bilal','Chentouf','b.chentouf@aui.ma',612345020,'AI'),
(148489,'Hajar','Azzouz','h.azzouz@aui.ma',612345021,'CSC'),
(148490,'Othmane','Jabrane','o.jabrane@aui.ma',612345022,'BA'),
(148491,'Younes','Bennouna','y.bennouna@aui.ma',612345023,'GE'),
(148492,'Siham','Fettah','s.fettah@aui.ma',612345024,'EMS'),
(148493,'Zakaria','El Azzouzi','z.elazzouzi@aui.ma',612345025,'AI'),
(148494,'Ghita','Rachidi','g.rachidi@aui.ma',612345026,'CSC'),
(148495,'Saad','El Mansouri','s.elmansouri@aui.ma',612345027,'BA'),
(148496,'Marouane','Hamdani','m.hamdani@aui.ma',612345028,'GE'),
(148497,'Nada','Serraj','n.serraj@aui.ma',612345029,'EMS'),
(148498,'Hamza','Bennaceur','h.bennaceur@aui.ma',612345030,'AI'),
(148499,'Salim','Bouhmid','s.bouhmid@aui.ma',612345031,'CSC'),
(148500,'Loubna','Chafik','l.chafik@aui.ma',612345032,'BA'),
(148501,'Imad','El Fakir','i.elfakir@aui.ma',612345033,'GE'),
(148502,'Wiam','Bennani','w.bennani2@aui.ma',612345034,'EMS'),
(148503,'Adil','Mernissi','a.mernissi@aui.ma',612345035,'AI');

-- ================================================
-- COACHES (FIXED ERROR HERE)
-- ================================================
INSERT INTO Coach VALUES
(3001,'Nabil','Karim','n.karim@aui.ma',670001111),
(3002,'Rania','Fassi','r.fassi@aui.ma',670002222),
(3003,'Omar','Lahlou','o.lahlou@aui.ma',670003333),
(3004,'Youssef','El Idrissi','y.elidrissi@aui.ma',670004444),
(3005,'Sara','Benali','s.beni@aui.ma',670005555);

-- ================================================
-- CLUBS
-- ================================================
INSERT INTO Club VALUES
(4001,'FalconFC','Football','falcon.fc@aui.ma'),
(4002,'AUIHoops','Basketball','aui.hoops@aui.ma'),
(4003,'SpikeForce','Volleyball','spike.force@aui.ma');

-- ================================================
-- TEAMS
-- ================================================
INSERT INTO Team VALUES
(5001,'Falcon A',3001,4001),
(5002,'Hoops A',3002,4002),
(5003,'Spike A',3003,4003);

-- ================================================
-- FACILITIES
-- ================================================
INSERT INTO Facility VALUES
(6001,'Main Field','North Campus',120),
(6002,'Indoor Court','Sports Center',80),
(6003,'Arena Hall','South Wing',150);

-- ================================================
-- TRYOUTS (FIXED COMMAS)
-- ================================================
INSERT INTO Tryout VALUES
(8001,'2026-05-10',5001,6001),
(8002,'2026-05-12',5002,6002),
(8003,'2026-05-15',5003,6003),
(8004,'2026-05-18',5001,6002),
(8005,'2026-05-20',5002,6001),
(8006,'2026-05-22',5003,6003);

-- ================================================
-- PRACTICES (FIXED COMMAS)
-- ================================================
INSERT INTO PracticeSession VALUES
(9001,'2026-05-05','17:00','19:00',5001,6001),
(9002,'2026-05-06','16:00','18:00',5002,6002),
(9003,'2026-05-07','18:00','20:00',5003,6003),
(9004,'2026-05-08','17:00','19:00',5001,6001),
(9005,'2026-05-09','16:00','18:00',5002,6002),
(9006,'2026-05-10','17:00','19:00',5003,6003),
(9007,'2026-05-11','16:00','18:00',5001,6001),
(9008,'2026-05-12','18:00','20:00',5002,6002);

-- ================================================
-- BOOKINGS (FIXED COMMAS)
-- ================================================
INSERT INTO FacilityBooking VALUES
(10001,'2026-05-06','15:00','17:00','Approved',6001,5001),
(10002,'2026-05-07','14:00','16:00','Approved',6002,5002),
(10003,'2026-05-08','13:00','15:00','Pending',6003,5003),
(10004,'2026-05-10','10:00','12:00','Pending',6001,5002),
(10005,'2026-05-11','10:00','12:00','Approved',6002,5001),
(10006,'2026-05-12','12:00','14:00','Pending',6001,5003),
(10007,'2026-05-13','16:00','18:00','Pending',6002,5002),
(10008,'2026-05-14','18:00','20:00','Approved',6003,5001);


-- ================================================
-- GAMES (FIXED COMMAS)
-- ================================================
INSERT INTO Game VALUES
(11001,'Rabat Rangers','2026-04-10',2,1,5001,6001),
(11002,'Meknes Giants','2026-04-12',67,59,5002,6002),
(11003,'Casa Waves','2026-04-15',3,2,5003,6003),
(11004,'Fes Eagles','2026-04-20',1,3,5001,6001),
(11005,'Marrakech Aces','2026-04-25',58,62,5002,6002),
(11006,'Rabat Lions','2026-04-28',2,2,5001,6002),
(11007,'Casa Waves','2026-04-30',1,0,5003,6001),
(11008,'Fes Eagles','2026-05-02',3,1,5002,6003);

-- ================================================

INSERT INTO Membership VALUES

-- =========================
-- TEAM 5001 (Falcon A - Football)
-- =========================
(148457, 5001, 'Starter', '2026-02-20'),
(148458, 5001, 'Defender', '2026-02-21'),
(148460, 5001, 'Midfielder', '2026-02-22'),
(148461, 5001, 'Starter', '2026-02-23'),
(148462, 5001, 'Defender', '2026-02-24'),
(148463, 5001, 'Substitute', '2026-02-25'),
(148465, 5001, 'Starter', '2026-02-26'),
(148466, 5001, 'Midfielder', '2026-02-27'),
(148467, 5001, 'Defender', '2026-02-28'),
(148468, 5001, 'Starter', '2026-03-01'),
(148470, 5001, 'Captain', '2026-03-02'),
(148471, 5001, 'Starter', '2026-03-03'),
(148472, 5001, 'Midfielder', '2026-03-04'),
(148473, 5001, 'Defender', '2026-03-05'),
(148475, 5001, 'Substitute', '2026-03-06'),
(148479, 5001, 'Starter', '2026-03-07'),
(148480, 5001, 'Midfielder', '2026-03-07'),
(148481, 5001, 'Defender', '2026-03-08'),
(148482, 5001, 'Starter', '2026-03-08'),
(148483, 5001, 'Substitute', '2026-03-09'),
(148484, 5001, 'Starter', '2026-03-09'),
(148485, 5001, 'Midfielder', '2026-03-10'),
(148486, 5001, 'Defender', '2026-03-10'),
(148487, 5001, 'Starter', '2026-03-11'),
(148488, 5001, 'Substitute', '2026-03-11'),
(148489, 5001, 'Starter', '2026-03-12'),
(148490, 5001, 'Midfielder', '2026-03-12'),

-- =========================
-- TEAM 5002 (Hoops A - Basketball)
-- =========================
(148456, 5002, 'Starter', '2026-02-20'),
(148457, 5002, 'Point Guard', '2026-02-21'),
(148458, 5002, 'Shooting Guard', '2026-02-22'),
(148461, 5002, 'Starter', '2026-02-23'),
(148462, 5002, 'Defender', '2026-02-24'),
(148463, 5002, 'Substitute', '2026-02-25'),
(148466, 5002, 'Starter', '2026-02-26'),
(148467, 5002, 'Midfielder', '2026-02-27'),
(148468, 5002, 'Defender', '2026-02-28'),
(148471, 5002, 'Starter', '2026-03-01'),
(148472, 5002, 'Captain', '2026-03-02'),
(148473, 5002, 'Starter', '2026-03-03'),
(148476, 5002, 'Substitute', '2026-03-04'),
(148477, 5002, 'Starter', '2026-03-05'),

-- =========================
-- TEAM 5003 (Spike A - Volleyball)
-- =========================
(148454, 5003, 'Libero', '2026-02-20'),
(148455, 5003, 'Setter', '2026-02-21'),
(148457, 5003, 'Outside Hitter', '2026-02-22'),
(148458, 5003, 'Starter', '2026-02-23'),
(148460, 5003, 'Defender', '2026-02-24'),
(148462, 5003, 'Starter', '2026-02-25'),
(148463, 5003, 'Substitute', '2026-02-26'),
(148465, 5003, 'Starter', '2026-02-27'),
(148467, 5003, 'Midfielder', '2026-02-28'),
(148468, 5003, 'Defender', '2026-03-01'),
(148470, 5003, 'Captain', '2026-03-02'),
(148471, 5003, 'Starter', '2026-03-03');
