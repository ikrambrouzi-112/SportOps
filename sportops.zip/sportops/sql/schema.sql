-- ================================================
-- SportOps – University Athletics Management System
-- Full Schema with Authentication
-- ================================================

DROP DATABASE IF EXISTS "SportsOpsDB";
CREATE DATABASE "SportsOpsDB";
\c "SportsOpsDB";

-- ------------------------------------------------
-- CORE ENTITIES
-- ------------------------------------------------

CREATE TABLE Student (
    student_id   INT          NOT NULL PRIMARY KEY,
    student_fname VARCHAR(20) NOT NULL,
    student_lname VARCHAR(20) NOT NULL,
    student_email VARCHAR(50) NOT NULL UNIQUE,
    student_pnumber BIGINT    UNIQUE,
    major        VARCHAR(5)   NOT NULL
);

CREATE TABLE Coach (
    coach_id    INT          NOT NULL PRIMARY KEY,
    coach_fname  VARCHAR(20) NOT NULL,
    coach_lname  VARCHAR(20) NOT NULL,
    coach_email  VARCHAR(50) NOT NULL UNIQUE,
    coach_pnumber BIGINT     UNIQUE
);

CREATE TABLE Club (
    club_id    INT          NOT NULL PRIMARY KEY,
    club_name  VARCHAR(30)  NOT NULL UNIQUE,
    sport_type VARCHAR(30)  NOT NULL,
    club_email VARCHAR(50)  NOT NULL UNIQUE
);

CREATE TABLE Team (
    team_id   INT         NOT NULL PRIMARY KEY,
    team_name VARCHAR(30) NOT NULL,
    coach_id  INT         NOT NULL,
    club_id   INT         NOT NULL,
    CONSTRAINT Manages  FOREIGN KEY(coach_id) REFERENCES Coach(coach_id),
    CONSTRAINT HasTeams FOREIGN KEY(club_id)  REFERENCES Club(club_id)
);

CREATE TABLE Facility (
    facility_id   INT         NOT NULL PRIMARY KEY,
    facility_name VARCHAR(30) NOT NULL UNIQUE,
    location      VARCHAR(50) NOT NULL,
    capacity      INT         NOT NULL
);

-- ------------------------------------------------
-- SCHEDULING / OPERATIONS
-- ------------------------------------------------

CREATE TABLE FacilityHours (
    hours_id    INT     NOT NULL PRIMARY KEY,
    day_of_week VARCHAR(9) NOT NULL CHECK (
        day_of_week IN ('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')
    ),
    open_time   TIME NOT NULL,
    close_time  TIME NOT NULL,
    facility_id INT  NOT NULL,
    CONSTRAINT HasHours FOREIGN KEY(facility_id) REFERENCES Facility(facility_id)
);

CREATE TABLE Tryout (
    tryout_id   INT  NOT NULL PRIMARY KEY,
    tryout_date DATE NOT NULL,
    team_id     INT  NOT NULL,
    facility_id INT  NOT NULL,
    CONSTRAINT Organizes FOREIGN KEY(team_id)     REFERENCES Team(team_id),
    CONSTRAINT HeldAt    FOREIGN KEY(facility_id) REFERENCES Facility(facility_id)
);

CREATE TABLE PracticeSession (
    practice_id   INT  NOT NULL PRIMARY KEY,
    practice_date DATE NOT NULL,
    start_time    TIME NOT NULL,
    end_time      TIME NOT NULL,
    team_id       INT  NOT NULL,
    facility_id   INT  NOT NULL,
    CONSTRAINT Schedules  FOREIGN KEY(team_id)     REFERENCES Team(team_id),
    CONSTRAINT PracticeAt FOREIGN KEY(facility_id) REFERENCES Facility(facility_id)
);

CREATE TABLE FacilityBooking (
    booking_id   INT         NOT NULL PRIMARY KEY,
    booking_date DATE        NOT NULL,
    start_time   TIME        NOT NULL,
    end_time     TIME        NOT NULL,
    status       VARCHAR(20) NOT NULL CHECK (status IN ('Pending','Approved','Rejected')),
    facility_id  INT         NOT NULL,
    team_id      INT         NOT NULL,
    CONSTRAINT BookedFor FOREIGN KEY(facility_id) REFERENCES Facility(facility_id),
    CONSTRAINT Requests  FOREIGN KEY(team_id)     REFERENCES Team(team_id)
);

CREATE TABLE Game (
    game_id        INT         NOT NULL PRIMARY KEY,
    opponent_name  VARCHAR(30) NOT NULL,
    game_date      DATE        NOT NULL,
    team_score     INT         NOT NULL,
    opponent_score INT         NOT NULL,
    team_id        INT         NOT NULL,
    facility_id    INT         NOT NULL,
    CONSTRAINT Plays    FOREIGN KEY(team_id)     REFERENCES Team(team_id),
    CONSTRAINT HostedAt FOREIGN KEY(facility_id) REFERENCES Facility(facility_id)
);

-- ------------------------------------------------
-- JUNCTION / RELATIONSHIP TABLES
-- ------------------------------------------------

CREATE TABLE Registers (
    student_id          INT         NOT NULL,
    tryout_id           INT         NOT NULL,
    registration_status VARCHAR(20) NOT NULL,
    PRIMARY KEY(student_id, tryout_id),
    CONSTRAINT register_student FOREIGN KEY(student_id) REFERENCES Student(student_id),
    CONSTRAINT register_tryout  FOREIGN KEY(tryout_id)  REFERENCES Tryout(tryout_id)
);

CREATE TABLE Scores (
    student_id INT  NOT NULL,
    game_id    INT  NOT NULL,
    goal_time  TIME NOT NULL,
    PRIMARY KEY(goal_time, game_id),
    CONSTRAINT score_student FOREIGN KEY(student_id) REFERENCES Student(student_id),
    CONSTRAINT score_game    FOREIGN KEY(game_id)    REFERENCES Game(game_id)
);

CREATE TABLE Membership (
    student_id INT         NOT NULL,
    team_id    INT         NOT NULL,
    role       VARCHAR(30),
    join_date  DATE,
    PRIMARY KEY(student_id, team_id),
    CONSTRAINT membership_student FOREIGN KEY(student_id) REFERENCES Student(student_id),
    CONSTRAINT membership_team    FOREIGN KEY(team_id)    REFERENCES Team(team_id)
);

-- ------------------------------------------------
-- AUTHENTICATION  (separate from domain tables)
-- ------------------------------------------------

CREATE TABLE Users (
    user_id       SERIAL      PRIMARY KEY,
    email         VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(100) NOT NULL,
    role          VARCHAR(10) NOT NULL CHECK (role IN ('athlete','coach','admin')),
    ref_id        INT         -- links to student_id or coach_id; NULL for admin
);
