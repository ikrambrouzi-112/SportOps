const express = require("express");
const pool    = require("../db");
const auth    = require("../middleware/auth");
const role    = require("../middleware/role");

const router = express.Router();

// GET /games
router.get("/", auth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT g.game_id, g.game_date, g.opponent_name,
             g.team_score, g.opponent_score,
             t.team_name, cl.sport_type,
             f.facility_name, f.location,
             CASE WHEN g.team_score > g.opponent_score THEN 'Win'
                  WHEN g.team_score < g.opponent_score THEN 'Loss'
                  ELSE 'Draw' END AS result
      FROM Game g
      JOIN Team t     ON g.team_id     = t.team_id
      JOIN Club cl    ON t.club_id     = cl.club_id
      JOIN Facility f ON g.facility_id = f.facility_id
      ORDER BY g.game_date DESC
    `);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// POST /games  (admin/coach)
router.post("/", auth, role("admin","coach"), async (req, res) => {
  try {
    const { opponent_name, game_date, team_score, opponent_score, team_id, facility_id } = req.body;
    const result = await pool.query(
      `INSERT INTO Game (game_id,opponent_name,game_date,team_score,opponent_score,team_id,facility_id)
       VALUES ((SELECT COALESCE(MAX(game_id),11000)+1 FROM Game),$1,$2,$3,$4,$5,$6)
       RETURNING *`,
      [opponent_name, game_date, team_score, opponent_score, team_id, facility_id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

module.exports = router;
