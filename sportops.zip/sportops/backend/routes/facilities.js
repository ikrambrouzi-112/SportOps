const express = require("express");
const pool    = require("../db");
const auth    = require("../middleware/auth");
const role    = require("../middleware/role");

const router = express.Router();

// GET /facilities
router.get("/", auth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT f.facility_id, f.facility_name, f.location, f.capacity,
             COUNT(DISTINCT fb.booking_id) AS total_bookings,
             COUNT(DISTINCT p.practice_id) AS total_practices,
             COUNT(DISTINCT g.game_id)     AS total_games
      FROM Facility f
      LEFT JOIN FacilityBooking fb ON f.facility_id = fb.facility_id
      LEFT JOIN PracticeSession p  ON f.facility_id = p.facility_id
      LEFT JOIN Game g             ON f.facility_id = g.facility_id
      GROUP BY f.facility_id, f.facility_name, f.location, f.capacity
      ORDER BY f.facility_name
    `);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// GET /facilities/:id/hours
router.get("/:id/hours", auth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT day_of_week, open_time, close_time
      FROM FacilityHours
      WHERE facility_id = $1
      ORDER BY ARRAY_POSITION(
        ARRAY['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
        day_of_week)
    `, [req.params.id]);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// GET /facilities/availability?date=YYYY-MM-DD&start=HH:MM&end=HH:MM
router.get("/availability", auth, async (req, res) => {
  try {
    const { date, start, end } = req.query;
    if (!date) return res.status(400).json({ message: "date is required." });

    const dayNames = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    const dayName  = dayNames[new Date(date).getDay()];

    const result = await pool.query(`
      SELECT f.facility_id, f.facility_name, f.location, f.capacity,
             fh.day_of_week, fh.open_time, fh.close_time,
             CASE
               WHEN fb.status = 'Approved' THEN 'Booked'
               WHEN p.practice_id IS NOT NULL THEN 'Practice'
               WHEN g.game_id IS NOT NULL THEN 'Game'
               ELSE 'Available'
             END AS availability,
             COALESCE(fb.start_time, p.start_time) AS event_start,
             COALESCE(fb.end_time,   p.end_time)   AS event_end
      FROM Facility f
      JOIN FacilityHours fh ON f.facility_id = fh.facility_id
                            AND fh.day_of_week = $2
      LEFT JOIN FacilityBooking fb ON f.facility_id = fb.facility_id
                                   AND fb.booking_date = $1
                                   AND fb.status = 'Approved'
      LEFT JOIN PracticeSession p  ON f.facility_id = p.facility_id
                                   AND p.practice_date = $1
      LEFT JOIN Game g             ON f.facility_id = g.facility_id
                                   AND g.game_date = $1
      ORDER BY f.facility_name
    `, [date, dayName]);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// POST /facilities  (admin)
router.post("/", auth, role("admin"), async (req, res) => {
  try {
    const { facility_name, location, capacity } = req.body;
    const result = await pool.query(
      `INSERT INTO Facility (facility_id, facility_name, location, capacity)
       VALUES ((SELECT COALESCE(MAX(facility_id),6000)+1 FROM Facility),$1,$2,$3)
       RETURNING *`,
      [facility_name, location, capacity]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

module.exports = router;
