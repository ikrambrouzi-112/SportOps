const express = require("express");
const pool    = require("../db");
const auth    = require("../middleware/auth");
const role    = require("../middleware/role");

const router = express.Router();

// GET /teams/options
// Minimal lookup data for team creation forms.
router.get("/options", auth, async (req, res) => {
  try {
    const [coaches, clubs] = await Promise.all([
      pool.query(`
        SELECT coach_id, coach_fname, coach_lname, coach_email
        FROM Coach
        ORDER BY coach_fname, coach_lname
      `),
      pool.query(`
        SELECT club_id, club_name, sport_type
        FROM Club
        ORDER BY club_name
      `),
    ]);

    res.json({ coaches: coaches.rows, clubs: clubs.rows });
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// GET /teams
router.get("/", auth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT t.team_id, t.team_name,
             c.coach_fname, c.coach_lname, c.coach_email,
             cl.club_name, cl.sport_type,
             COUNT(m.student_id) AS member_count
      FROM Team t
      JOIN Coach c  ON t.coach_id = c.coach_id
      JOIN Club cl  ON t.club_id  = cl.club_id
      LEFT JOIN Membership m ON t.team_id = m.team_id
      GROUP BY t.team_id, t.team_name, c.coach_fname, c.coach_lname,
               c.coach_email, cl.club_name, cl.sport_type
      ORDER BY t.team_name
    `);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// GET /teams/:id/members
router.get("/:id/members", auth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT s.student_id, s.student_fname, s.student_lname,
             s.student_email, s.major, m.role, m.join_date
      FROM Membership m
      JOIN Student s ON m.student_id = s.student_id
      WHERE m.team_id = $1
      ORDER BY m.role, s.student_fname
    `, [req.params.id]);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// GET /teams/:id/schedule  (practices + games)
router.get("/:id/schedule", auth, async (req, res) => {
  try {
    const practices = await pool.query(`
      SELECT 'practice' AS type, p.practice_date AS date,
             p.start_time, p.end_time, f.facility_name
      FROM PracticeSession p
      JOIN Facility f ON p.facility_id = f.facility_id
      WHERE p.team_id = $1
      ORDER BY p.practice_date, p.start_time
    `, [req.params.id]);
    const games = await pool.query(`
      SELECT 'game' AS type, g.game_date AS date,
             g.opponent_name, g.team_score, g.opponent_score,
             f.facility_name,
             CASE WHEN g.team_score > g.opponent_score THEN 'Win'
                  WHEN g.team_score < g.opponent_score THEN 'Loss'
                  ELSE 'Draw' END AS result
      FROM Game g
      JOIN Facility f ON g.facility_id = f.facility_id
      WHERE g.team_id = $1
      ORDER BY g.game_date DESC
    `, [req.params.id]);
    res.json({ practices: practices.rows, games: games.rows });
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// POST /teams  (admin only)
router.post("/", auth, role("admin"), async (req, res) => {
  try {
    const { team_name, coach_id, club_id } = req.body;

    if (!team_name || !coach_id || !club_id) {
      return res.status(400).json({ message: "team_name, coach_id, and club_id are required." });
    }

    const result = await pool.query(
      `INSERT INTO Team (team_id, team_name, coach_id, club_id)
       VALUES ((SELECT COALESCE(MAX(team_id),5000)+1 FROM Team), $1, $2, $3)
       RETURNING *`,
      [team_name.trim(), Number(coach_id), Number(club_id)]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

module.exports = router;
