const express = require("express");
const pool    = require("../db");
const auth    = require("../middleware/auth");

const router = express.Router();

// GET /dashboard/stats  – summary numbers (role-aware)
router.get("/stats", auth, async (req, res) => {
  try {
    const { role, ref_id } = req.user;

    if (role === "admin") {
      const [students, teams, facilities, bookings, tryouts, games] = await Promise.all([
        pool.query("SELECT COUNT(*) FROM Student"),
        pool.query("SELECT COUNT(*) FROM Team"),
        pool.query("SELECT COUNT(*) FROM Facility"),
        pool.query("SELECT COUNT(*) FROM FacilityBooking WHERE status='Pending'"),
        pool.query("SELECT COUNT(*) FROM Tryout WHERE tryout_date >= CURRENT_DATE"),
        pool.query("SELECT COUNT(*) FROM Game"),
      ]);
      return res.json({
        students:        parseInt(students.rows[0].count),
        teams:           parseInt(teams.rows[0].count),
        facilities:      parseInt(facilities.rows[0].count),
        pending_bookings:parseInt(bookings.rows[0].count),
        upcoming_tryouts:parseInt(tryouts.rows[0].count),
        total_games:     parseInt(games.rows[0].count),
      });
    }

    if (role === "coach") {
      const teamRes = await pool.query(
        "SELECT team_id FROM Team WHERE coach_id = $1", [ref_id]
      );
      const teamIds = teamRes.rows.map(r => r.team_id);
      if (!teamIds.length) return res.json({ teams: 0, members: 0, upcoming_practices: 0, games_played: 0 });

      const [members, practices, games, bookings] = await Promise.all([
        pool.query(`SELECT COUNT(*) FROM Membership WHERE team_id = ANY($1::int[])`, [teamIds]),
        pool.query(`SELECT COUNT(*) FROM PracticeSession WHERE team_id = ANY($1::int[]) AND practice_date >= CURRENT_DATE`, [teamIds]),
        pool.query(`SELECT COUNT(*) FROM Game WHERE team_id = ANY($1::int[])`, [teamIds]),
        pool.query(`SELECT COUNT(*) FROM FacilityBooking WHERE team_id = ANY($1::int[]) AND status='Pending'`, [teamIds]),
      ]);
      return res.json({
        teams:              teamIds.length,
        members:            parseInt(members.rows[0].count),
        upcoming_practices: parseInt(practices.rows[0].count),
        games_played:       parseInt(games.rows[0].count),
        pending_bookings:   parseInt(bookings.rows[0].count),
      });
    }

    // athlete
    const [teams, tryoutsAttempted, upcomingTryouts] = await Promise.all([
      pool.query("SELECT COUNT(*) FROM Membership WHERE student_id = $1", [ref_id]),
      pool.query(`SELECT COUNT(*) FROM Registers r JOIN Tryout t ON r.tryout_id=t.tryout_id
                  WHERE r.student_id=$1 AND t.tryout_date < CURRENT_DATE`, [ref_id]),
      pool.query(`SELECT COUNT(*) FROM Registers r JOIN Tryout t ON r.tryout_id=t.tryout_id
                  WHERE r.student_id=$1 AND t.tryout_date >= CURRENT_DATE`, [ref_id]),
    ]);
    return res.json({
      teams_joined:     parseInt(teams.rows[0].count),
      tryouts_attempted:parseInt(tryoutsAttempted.rows[0].count),
      upcoming_tryouts: parseInt(upcomingTryouts.rows[0].count),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error." });
  }
});

// GET /dashboard/team-size  – for bar chart
router.get("/team-size", auth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT t.team_name, c.sport_type, c.club_name,
             COUNT(m.student_id) AS size
      FROM Team t
      JOIN Club c ON t.club_id = c.club_id
      LEFT JOIN Membership m ON t.team_id = m.team_id
      GROUP BY t.team_name, c.sport_type, c.club_name
      ORDER BY t.team_name
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ message: "Server error." });
  }
});

// GET /dashboard/upcoming  – upcoming events (next 14 days)
router.get("/upcoming", auth, async (req, res) => {
  try {
    const tryouts = await pool.query(`
      SELECT 'tryout' AS type, t.tryout_date AS event_date,
             tm.team_name, c.sport_type, f.facility_name
      FROM Tryout t
      JOIN Team tm ON t.team_id = tm.team_id
      JOIN Club c  ON tm.club_id = c.club_id
      JOIN Facility f ON t.facility_id = f.facility_id
      WHERE t.tryout_date BETWEEN CURRENT_DATE AND CURRENT_DATE + 14
      ORDER BY t.tryout_date
      LIMIT 5
    `);
    const practices = await pool.query(`
      SELECT 'practice' AS type, p.practice_date AS event_date,
             p.start_time, p.end_time,
             tm.team_name, f.facility_name
      FROM PracticeSession p
      JOIN Team tm     ON p.team_id     = tm.team_id
      JOIN Facility f  ON p.facility_id = f.facility_id
      WHERE p.practice_date BETWEEN CURRENT_DATE AND CURRENT_DATE + 14
      ORDER BY p.practice_date, p.start_time
      LIMIT 5
    `);
    res.json({ tryouts: tryouts.rows, practices: practices.rows });
  } catch (err) {
    res.status(500).json({ message: "Server error." });
  }
});

// GET /dashboard/game-results  – recent games
router.get("/game-results", auth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT c.sport_type, tm.team_name, g.opponent_name,
             g.game_date, g.team_score, g.opponent_score,
             CASE WHEN g.team_score > g.opponent_score THEN 'Win'
                  WHEN g.team_score < g.opponent_score THEN 'Loss'
                  ELSE 'Draw' END AS result
      FROM Game g
      JOIN Team tm ON g.team_id = tm.team_id
      JOIN Club c  ON tm.club_id = c.club_id
      ORDER BY g.game_date DESC
      LIMIT 5
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ message: "Server error." });
  }
});

module.exports = router;
