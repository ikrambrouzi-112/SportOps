const express = require("express");
const pool    = require("../db");
const auth    = require("../middleware/auth");
const role    = require("../middleware/role");

const router = express.Router();

// GET /bookings
router.get("/", auth, async (req, res) => {
  try {
    let query, params;
    if (req.user.role === "admin") {
      query = `
        SELECT fb.booking_id, fb.booking_date, fb.start_time, fb.end_time,
               fb.status, f.facility_name, f.location,
               t.team_name, cl.sport_type
        FROM FacilityBooking fb
        JOIN Facility f ON fb.facility_id = f.facility_id
        JOIN Team t     ON fb.team_id     = t.team_id
        JOIN Club cl    ON t.club_id      = cl.club_id
        ORDER BY fb.booking_date DESC, fb.start_time
      `;
      params = [];
    } else if (req.user.role === "coach") {
      query = `
        SELECT fb.booking_id, fb.booking_date, fb.start_time, fb.end_time,
               fb.status, f.facility_name, f.location, t.team_name
        FROM FacilityBooking fb
        JOIN Facility f ON fb.facility_id = f.facility_id
        JOIN Team t     ON fb.team_id     = t.team_id
        WHERE t.coach_id = $1
        ORDER BY fb.booking_date DESC
      `;
      params = [req.user.ref_id];
    } else {
      return res.status(403).json({ message: "Access denied." });
    }
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// POST /bookings  (coach)
router.post("/", auth, role("coach","admin"), async (req, res) => {
  try {
    const { facility_id, team_id, booking_date, start_time, end_time } = req.body;

    // conflict check
    const conflict = await pool.query(`
      SELECT 1 FROM FacilityBooking
      WHERE facility_id=$1 AND booking_date=$2 AND status='Approved'
        AND NOT ($3::time >= end_time OR $4::time <= start_time)
    `, [facility_id, booking_date, end_time, start_time]);
    if (conflict.rows.length)
      return res.status(409).json({ message: "Time slot already booked." });

    const result = await pool.query(
      `INSERT INTO FacilityBooking
         (booking_id, booking_date, start_time, end_time, status, facility_id, team_id)
       VALUES
         ((SELECT COALESCE(MAX(booking_id),10000)+1 FROM FacilityBooking),
          $1,$2,$3,'Pending',$4,$5)
       RETURNING *`,
      [booking_date, start_time, end_time, facility_id, team_id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// PATCH /bookings/:id/approve  (admin only)
router.patch("/:id/approve", auth, role("admin"), async (req, res) => {
  try {
    await pool.query(
      "UPDATE FacilityBooking SET status='Approved' WHERE booking_id=$1",
      [req.params.id]
    );
    res.json({ message: "Booking approved." });
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// PATCH /bookings/:id/reject  (admin only)
router.patch("/:id/reject", auth, role("admin"), async (req, res) => {
  try {
    await pool.query(
      "UPDATE FacilityBooking SET status='Rejected' WHERE booking_id=$1",
      [req.params.id]
    );
    res.json({ message: "Booking rejected." });
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

module.exports = router;
