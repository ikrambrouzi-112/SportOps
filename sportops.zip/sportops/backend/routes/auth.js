const express = require("express");
const bcrypt  = require("bcrypt");
const jwt     = require("jsonwebtoken");
const pool    = require("../db");
const auth    = require("../middleware/auth");

const router     = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "sportops_secret_2026";
const JWT_EXPIRY = "8h";

// ──────────────────────────────────────────────
// POST /auth/login
// ──────────────────────────────────────────────
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required." });
    }

    const result = await pool.query(
      "SELECT * FROM Users WHERE email = $1",
      [email.trim().toLowerCase()]
    );

    const user = result.rows[0];
    if (!user) {
      return res.status(404).json({ message: "Account not found." });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ message: "Incorrect password." });
    }

    // Fetch profile name from Student or Coach table
    let fname = "User", lname = "";
    if (user.role === "athlete" && user.ref_id) {
      const s = await pool.query(
        "SELECT student_fname, student_lname FROM Student WHERE student_id = $1",
        [user.ref_id]
      );
      if (s.rows[0]) { fname = s.rows[0].student_fname; lname = s.rows[0].student_lname; }
    } else if (user.role === "coach" && user.ref_id) {
      const c = await pool.query(
        "SELECT coach_fname, coach_lname FROM Coach WHERE coach_id = $1",
        [user.ref_id]
      );
      if (c.rows[0]) { fname = c.rows[0].coach_fname; lname = c.rows[0].coach_lname; }
    } else if (user.role === "admin") {
      fname = "Admin"; lname = "SportOps";
    }

    const token = jwt.sign(
      {
        user_id: user.user_id,
        ref_id:  user.ref_id,
        role:    user.role,
        email:   user.email,
        fname,
        lname,
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRY }
    );

    res.json({
      message: "Login successful.",
      token,
      role:  user.role,
      fname,
      lname,
      email: user.email,
      ref_id: user.ref_id,
    });

  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ message: "Server error." });
  }
});

// ──────────────────────────────────────────────
// GET /auth/me   (requires valid JWT)
// ──────────────────────────────────────────────
router.get("/me", auth, async (req, res) => {
  try {
    const { user_id, role, ref_id, email, fname, lname } = req.user;

    let profile = null;
    if (role === "athlete" && ref_id) {
      const s = await pool.query(
        "SELECT * FROM Student WHERE student_id = $1",
        [ref_id]
      );
      profile = s.rows[0] || null;
    } else if (role === "coach" && ref_id) {
      const c = await pool.query(
        "SELECT * FROM Coach WHERE coach_id = $1",
        [ref_id]
      );
      profile = c.rows[0] || null;
    }

    res.json({ user_id, role, ref_id, email, fname, lname, profile });
  } catch (err) {
    console.error("Me error:", err);
    res.status(500).json({ message: "Server error." });
  }
});

module.exports = router;
