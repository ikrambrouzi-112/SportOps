const express = require("express");
const pool    = require("../db");
const auth    = require("../middleware/auth");
const role    = require("../middleware/role");

const router = express.Router();

// GET /practices
router.get("/", auth, async (req, res) => {
  try {
    let query, params = [];
    if (req.user.role === "coach") {
      query = `
        SELECT p.practice_id, p.practice_date, p.start_time, p.end_time,
               t.team_name, f.facility_name, f.location
        FROM PracticeSession p
        JOIN Team t     ON p.team_id     = t.team_id
        JOIN Facility f ON p.facility_id = f.facility_id
        WHERE t.coach_id = $1
        ORDER BY p.practice_date, p.start_time
      `;
      params = [req.user.ref_id];
    } else {
      query = `
        SELECT p.practice_id, p.practice_date, p.start_time, p.end_time,
               t.team_name, f.facility_name, f.location
        FROM PracticeSession p
        JOIN Team t     ON p.team_id     = t.team_id
        JOIN Facility f ON p.facility_id = f.facility_id
        ORDER BY p.practice_date, p.start_time
      `;
    }
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// POST /practices  (coach/admin)
router.post("/", auth, role("coach","admin"), async (req, res) => {
  try {
    const { practice_date, start_time, end_time, team_id, facility_id } = req.body;
    const result = await pool.query(
      `INSERT INTO PracticeSession (practice_id,practice_date,start_time,end_time,team_id,facility_id)
       VALUES ((SELECT COALESCE(MAX(practice_id),9000)+1 FROM PracticeSession),$1,$2,$3,$4,$5)
       RETURNING *`,
      [practice_date, start_time, end_time, team_id, facility_id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

module.exports = router;
