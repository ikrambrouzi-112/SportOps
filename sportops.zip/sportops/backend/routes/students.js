const express = require("express");
const pool    = require("../db");
const auth    = require("../middleware/auth");
const role    = require("../middleware/role");

const router = express.Router();

// GET /students  (admin/coach)
router.get("/", auth, role("admin","coach"), async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT s.student_id, s.student_fname, s.student_lname,
             s.student_email, s.major,
             COUNT(DISTINCT m.team_id) AS teams_count
      FROM Student s
      LEFT JOIN Membership m ON s.student_id = m.student_id
      GROUP BY s.student_id, s.student_fname, s.student_lname,
               s.student_email, s.major
      ORDER BY s.student_lname, s.student_fname
    `);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// GET /students/:id/history  (athlete sees own; admin/coach sees any)
router.get("/:id/history", auth, async (req, res) => {
  try {
    const sid = parseInt(req.params.id);
    if (req.user.role === "athlete" && req.user.ref_id !== sid)
      return res.status(403).json({ message: "Access denied." });

    const memberships = await pool.query(`
      SELECT t.team_name, cl.sport_type, m.role, m.join_date,
             c.coach_fname, c.coach_lname
      FROM Membership m
      JOIN Team t  ON m.team_id  = t.team_id
      JOIN Club cl ON t.club_id  = cl.club_id
      JOIN Coach c ON t.coach_id = c.coach_id
      WHERE m.student_id = $1
      ORDER BY m.join_date DESC
    `, [sid]);

    const tryouts = await pool.query(`
      SELECT r.registration_status, r.tryout_id,
             t.team_name, cl.sport_type,
             tr.tryout_date, f.facility_name
      FROM Registers r
      JOIN Tryout tr   ON r.tryout_id  = tr.tryout_id
      JOIN Team t      ON tr.team_id   = t.team_id
      JOIN Club cl     ON t.club_id    = cl.club_id
      JOIN Facility f  ON tr.facility_id = f.facility_id
      WHERE r.student_id = $1
      ORDER BY tr.tryout_date DESC
    `, [sid]);

    res.json({ memberships: memberships.rows, tryouts: tryouts.rows });
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

module.exports = router;
