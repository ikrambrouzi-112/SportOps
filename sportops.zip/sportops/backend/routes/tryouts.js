const express = require("express");
const pool    = require("../db");
const auth    = require("../middleware/auth");
const role    = require("../middleware/role");

const router = express.Router();

// GET /tryouts
router.get("/", auth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT tr.tryout_id, tr.tryout_date,
             t.team_name, cl.sport_type, cl.club_name,
             f.facility_name, f.location,
             COUNT(r.student_id) AS registrations
      FROM Tryout tr
      JOIN Team t     ON tr.team_id     = t.team_id
      JOIN Club cl    ON t.club_id      = cl.club_id
      JOIN Facility f ON tr.facility_id = f.facility_id
      LEFT JOIN Registers r ON tr.tryout_id = r.tryout_id
      GROUP BY tr.tryout_id, tr.tryout_date,
               t.team_name, cl.sport_type, cl.club_name,
               f.facility_name, f.location
      ORDER BY tr.tryout_date
    `);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// GET /tryouts/upcoming
router.get("/upcoming", auth, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT tr.tryout_id, tr.tryout_date,
             t.team_name, cl.sport_type,
             f.facility_name, f.location
      FROM Tryout tr
      JOIN Team t     ON tr.team_id     = t.team_id
      JOIN Club cl    ON t.club_id      = cl.club_id
      JOIN Facility f ON tr.facility_id = f.facility_id
      WHERE tr.tryout_date >= CURRENT_DATE
      ORDER BY tr.tryout_date
    `);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// GET /tryouts/:id/participants  (coach/admin)
router.get("/:id/participants", auth, role("coach","admin"), async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT s.student_id, s.student_fname, s.student_lname,
             s.major, r.registration_status
      FROM Registers r
      JOIN Student s ON r.student_id = s.student_id
      WHERE r.tryout_id = $1
      ORDER BY r.registration_status, s.student_lname
    `, [req.params.id]);
    res.json(result.rows);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// POST /tryouts/register  (athlete)
router.post("/register", auth, role("athlete"), async (req, res) => {
  try {
    const student_id = req.user.ref_id;
    const { tryout_id } = req.body;
    if (!tryout_id) return res.status(400).json({ message: "tryout_id required." });

    // check already registered
    const exists = await pool.query(
      "SELECT 1 FROM Registers WHERE student_id=$1 AND tryout_id=$2",
      [student_id, tryout_id]
    );
    if (exists.rows.length)
      return res.status(409).json({ message: "Already registered for this tryout." });

    await pool.query(
      "INSERT INTO Registers (student_id, tryout_id, registration_status) VALUES ($1,$2,'Registered')",
      [student_id, tryout_id]
    );
    res.json({ message: "Registered successfully." });
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

// POST /tryouts  (admin/coach)
router.post("/", auth, role("admin","coach"), async (req, res) => {
  try {
    const { tryout_date, team_id, facility_id } = req.body;
    const result = await pool.query(
      `INSERT INTO Tryout (tryout_id, tryout_date, team_id, facility_id)
       VALUES ((SELECT COALESCE(MAX(tryout_id),8000)+1 FROM Tryout), $1, $2, $3)
       RETURNING *`,
      [tryout_date, team_id, facility_id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) { res.status(500).json({ message: "Server error." }); }
});

module.exports = router;
