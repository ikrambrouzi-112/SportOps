/**
 * seed.js – Creates demo login accounts in the Users table.
 * Run once after loading the schema and data:
 *   node seed.js
 */

const bcrypt = require("bcrypt");
const pool   = require("./db");

const SALT_ROUNDS = 10;

const users = [
  {
    email:    "admin@sportops.ma",
    password: "admin123",
    role:     "admin",
    ref_id:   null,
  },
  {
    email:    "b.guellass@aui.ma",
    password: "student123",
    role:     "athlete",
    ref_id:   148454,
  },
  {
    email:    "s.elidrissi@aui.ma",
    password: "student123",
    role:     "athlete",
    ref_id:   148455,
  },
  {
    email:    "y.amrani@aui.ma",
    password: "student123",
    role:     "athlete",
    ref_id:   148456,
  },
  {
    email:    "l.bennani@aui.ma",
    password: "student123",
    role:     "athlete",
    ref_id:   148457,
  },
  {
    email:    "h.alaoui@aui.ma",
    password: "student123",
    role:     "athlete",
    ref_id:   148458,
  },
  {
    email:    "m.tazi@aui.ma",
    password: "student123",
    role:     "athlete",
    ref_id:   148459,
  },
  {
    email:    "n.karim@aui.ma",
    password: "coach123",
    role:     "coach",
    ref_id:   3001,
  },
  {
    email:    "r.fassi@aui.ma",
    password: "coach123",
    role:     "coach",
    ref_id:   3002,
  },
  {
    email:    "o.lahlou@aui.ma",
    password: "coach123",
    role:     "coach",
    ref_id:   3003,
  },
];

async function seed() {
  console.log("Seeding demo accounts…");

  for (const u of users) {
    const hash = await bcrypt.hash(u.password, SALT_ROUNDS);
    try {
      await pool.query(
        `INSERT INTO Users (email, password_hash, role, ref_id)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash`,
        [u.email, hash, u.role, u.ref_id]
      );
      console.log(`  ✓  ${u.role.padEnd(7)}  ${u.email}`);
    } catch (err) {
      console.error(`  ✗  ${u.email}:`, err.message);
    }
  }

  console.log("\nDone! Demo credentials:");
  console.log("  Admin   : admin@sportops.ma   /  admin123");
  console.log("  Athlete : b.guellass@aui.ma   /  student123");
  console.log("  Coach   : n.karim@aui.ma      /  coach123");

  await pool.end();
}

seed();
