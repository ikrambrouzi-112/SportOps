const { Pool } = require("pg");

const pool = new Pool({
  user:     "postgres",
  host:     "localhost",
  database: "SportsOpsDB",
  password: "12345",   // ← change this
  port:     5432,
});

pool.on("error", (err) => {
  console.error("Unexpected DB error:", err);
});

module.exports = pool;
