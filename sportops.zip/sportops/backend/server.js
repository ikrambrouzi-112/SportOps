const express = require("express");
const cors    = require("cors");
const path    = require("path");

const app = express();

app.use(cors());
app.use(express.json());

// Serve frontend static files
app.use(express.static(path.join(__dirname, "../frontend")));

// API Routes
app.use("/auth",       require("./routes/auth"));
app.use("/dashboard",  require("./routes/dashboard"));
app.use("/students",   require("./routes/students"));
app.use("/teams",      require("./routes/teams"));
app.use("/tryouts",    require("./routes/tryouts"));
app.use("/facilities", require("./routes/facilities"));
app.use("/games",      require("./routes/games"));
app.use("/practices",  require("./routes/practices"));
app.use("/bookings",   require("./routes/bookings"));

// Catch-all: serve login page
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/login.html"));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`SportOps server running on http://localhost:${PORT}`);
});
