/**
 * requireRole(...roles)
 * Usage: router.get("/admin-only", auth, requireRole("admin"), handler)
 *        router.get("/staff",      auth, requireRole("admin","coach"), handler)
 */
module.exports = function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(403).json({ message: "Not authenticated." });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        message: `Access denied. Required role: ${roles.join(" or ")}.`,
      });
    }
    next();
  };
};
